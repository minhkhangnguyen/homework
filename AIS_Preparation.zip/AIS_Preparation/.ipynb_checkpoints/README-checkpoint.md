"""
Created on 16.10.2025

@author: cong liu
"""



# AIS Data Preparation

## Overview

This project provides a set of Python modules for cleaning and analyzing AIS data, with a particular focus on addressing common challenges such as inconsistent timestamps, duplicate records, and the detection of anomalies like abnormal drift points. It also includes modules for visualizing AIS data on a map to better understand the spatial distribution and characteristics of the data.


## Project Structure
The project is structured as follows:

├── libs/                          # Package containing all neccessary modules
│   ├── __init__.py                # This file marks this folder as a Python package 
│   ├── plot_traffic_on_map.py     # Module for plotting traffic on the map 
│   ├── time_processing.py         # Module for time conversion, sorting, and time difference calculations
│   ├── distance_calculation.py    # Module for calculating spatial distances
│   └── drift_detection.py         # Module for detecting trajectory drift points
├── main.ipynb                     # Main jupyter notebook that runs the full AIS data preparation workflow
└── README.md                      # Project guide and explanation

## Module description

There are four main modules, and each focuses on a specific task related to AIS data preparation. Each module contains one or more functions, which perform the actual operations on the AIS data.


### Module 1: `plot_traffic_on_map.py`
This module contains a function for creating a background map on which AIS positions can be plotted.

#### Create the background map using `plot_on_map(extent)`
- Purpose: Creates a map with coastlines, coloured land and ocean, and longitude and latitude labels.
- Parameters:
  - `extent`: The map boundaries, given as [minimum longitude, maximum longitude, minimum latitude, maximum latitude] in degrees.
  - If omitted, the default boundaries are [-4.7, -4.2, 48.1, 48.4].
- Returns:
  - `fig`: The Matplotlib figure containing the map.
  - `ax`: The map axes on which data can be plotted.

The function creates only the background map. AIS positions must be added separately to the returned `ax`, using the longitude and latitude columns from the dataset.

### Module 2: `time_processing.py`
This module contains 4 functions related to handling timestamp: (1) converting timestamps, (2) sorting data, (3) calculating time differences between consecutive points, and (4) remove the duplicate time entries. 

#### (1) converting timestamps is achieved using `convert_timeStr_pdtime(df_ais, time_column_name, time_format)`
  - Purpose: Converts the timestamp string in the AIS data into a `pandas` datetime object.
  - Parameters:
    - `df_ais`: DataFrame containing AIS data.
    - `time_column_name`: The column name with the timestamp data.
    - `time_format`: The format of the timestamp string (e.g., `'%Y-%m-%d %H:%M:%S'`).
  - Returns: DataFrame with the `timestamp` column converted to datetime and an additional `ts` column containing Unix timestamps in seconds.

#### (2) sorting data is achieved using `sort_data_vel_time(df_ais, vessel_column_name, time_column_name)`
  - Purpose: Sorts the AIS data by vessel identifier (MMSI) and timestamp.
  - Parameters:
    - `df_ais`: DataFrame containing AIS data.
    - `vessel_column_name`: The column name with vessel identifiers (MMSI).
    - `time_column_name`: The column name with timestamp data.
  - Returns: A sorted DataFrame.

#### (3) calculating time differences between consecutive points is achieved using `calculate_time_difference(df_ais, vessel_column_name, time_column_name, time_grain)`
  - Purpose: Calculates the time difference between consecutive AIS data points for each vessel, expressed in minutes or seconds.
  - Parameters:
    - `df_ais`: DataFrame containing AIS data.
    - `vessel_column_name`: The column name with vessel identifiers (MMSI).
    - `time_column_name`: The column name with timestamp data.
    - `time_grain`: The unit of time difference, either 'm' for minutes or 's' for seconds.
  - Returns: DataFrame with an additional column for time differences (`time_difference(min)` or `time_difference(s)`).

#### (4) removing duplicates is achieved using `remove_time_repeat_data(df_ais, time_diff_column_name)` 
  - Purpose: Removes duplicate records for the same vessel where the timestamp is identical to the previous record.
  - Parameters:
    - `df_ais`: DataFrame containing AIS data.
    - `time_diff_column_name`: The column name with calculated time differences.
  - Returns: A DataFrame with duplicate time entries removed.


### Module 3: `distance_calculation.py`

This module contains functions for calculating the spatial distances between consecutive AIS data points for each vessel.

#### (1) calculating spatial distances is achieved using `calculate_spatial_distance(df_ais, vessel_column_name)`
  - Purpose: Calculates the spatial distance (in kilometers) between consecutive AIS points for each vessel using the Haversine formula.
  - Parameters:
    - `df_ais`: DataFrame containing AIS data.
    - `vessel_column_name`: The column name with vessel identifiers (MMSI).
  - Returns: DataFrame with an additional column `spatial_distance(km)` containing the calculated distances.

#### (2) helper function - `_haversine(df, to_radians=True, earth_radius=6371)`
  - Purpose: A helper function that implements the Haversine formula to calculate the great-circle distance between two points on the Earth’s surface.
  - Parameters:
    - `df`: A subset of the DataFrame containing latitude and longitude data.
    - `to_radians`: Boolean flag indicating whether to convert degree values to radians (default is `True`).
    - `earth_radius`: The radius of the Earth in kilometers (default is `6371` km).
  - Returns: DataFrame with the computed spatial distances between points.


### Module 4: `drift_detection.py`
This module contains a main function and helper function to detect potential trajectory drift points within the AIS data.

#### (1) detecting drift points is achieved using `detect_trajectory_drift_point(df_ais, vessel_column_name)`
  - Purpose: Flags potential drift points when the distances to both the previous and next reported positions of the same vessel are at least 15 km, and both distances have absolute Z-scores greater than 3.
  - Parameters:
    - `df_ais`: DataFrame containing AIS data.
    - `vessel_column_name`: The column name with vessel identifiers (MMSI).
  - Returns: DataFrame with an additional column `drift_point`, which flags whether a point is identified as a drift point (`1` for drift, `0` for normal).

#### (2) helper function - `detection_abnormal(df)`
  - Purpose: This helper function, used within `detect_trajectory_drift_point`, calculates Z-scores for distances to detect outliers, marking them as drift points based on predefined thresholds.
  - Parameters:
     - `df_ais` : A subset of the DataFrame for a particular vessel.
  - Returns: A DataFrame with an additional `drift_point` column.

### Usage: `main.ipynb`

- This script,`main.ipynb`, ties together the functions from the `libs` folder to process AIS data systematically. It calls the necessary functions to visualize, convert, sort, and clean the data, preparing it for further analysis or visualization.
- Note: You can modify the script or modules in `libs` to customize the processing according to your needs.