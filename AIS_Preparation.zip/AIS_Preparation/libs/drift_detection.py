def detect_trajectory_drift_point(df_ais, vessel_column_name):
    '''Detect trajectory drift points by analyzing spatial distances'''
    df_ais['spatial_distance_next(km)'] = df_ais.groupby(vessel_column_name, as_index=False)['spatial_distance(km)'].shift(-1)

    
    
    def detection_abnormal(df):
        mean_distance = df['spatial_distance_next(km)'].mean()
        std_distance = df['spatial_distance_next(km)'].std()

        z_scores_1 = (df['spatial_distance(km)'] - mean_distance) / std_distance
        z_scores_2 = (df['spatial_distance_next(km)'] - mean_distance) / std_distance

        threshold = 3
        df['drift_point'] = 0
        df.loc[(abs(z_scores_1) > threshold) & (abs(z_scores_2) > threshold) & 
               (df['spatial_distance(km)'] >= 15) & 
               (df['spatial_distance_next(km)'] >= 15), 'drift_point'] = 1

        return df
    df_ais = df_ais.groupby(vessel_column_name, as_index=False).apply(detection_abnormal).reset_index(drop=True)
    
    return df_ais
