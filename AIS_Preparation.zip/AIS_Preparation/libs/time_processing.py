import pandas as pd

def convert_timeStr_pdtime(df_ais, time_column_name, time_format):
    '''Convert the timestamp into the format of pd.datetime'''
    df_ais['timestamp'] = pd.to_datetime(df_ais[time_column_name], format=time_format)
    df_ais['ts'] = df_ais['timestamp'].astype('int64') // 10**9
    return df_ais

def sort_data_vel_time(df_ais, vessel_column_name, time_column_name):
    '''Sort the ship trajectories by MMSI and timestamp'''
    df_ais_sorted = df_ais.sort_values(by=[vessel_column_name, time_column_name], ascending=True)
    return df_ais_sorted

def calculate_time_difference(df_ais, vessel_column_name, time_column_name, time_grain):
    '''Calculate the time difference between two consecutive points'''
    if time_grain == 'm':
        df_ais['time_difference(min)'] = df_ais.groupby(vessel_column_name, as_index=False)[time_column_name].diff()/60
    if time_grain == 's':
        df_ais['time_difference(s)'] = df_ais.groupby(vessel_column_name, as_index=False)[time_column_name].diff().astype('timedelta64[s]')
    return df_ais

def remove_time_repeat_data(df_ais, time_diff_column_name):
    '''Remove data with the same timestamp for the same vessel'''
    df_ais_no_repeat = df_ais[~df_ais[time_diff_column_name].isin([0])]
    return df_ais_no_repeat
