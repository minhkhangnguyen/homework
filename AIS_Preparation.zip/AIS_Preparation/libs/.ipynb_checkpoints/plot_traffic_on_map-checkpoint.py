import cartopy.crs as crs
import cartopy.feature as cfeature
import matplotlib.ticker as mticker
import matplotlib.pyplot as plt
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER

def plot_on_map(extent=[-4.7, -4.2, 48.1, 48.4]):
    '''create the colored basic map with extent limits'''
    fig = plt.figure(figsize=(10, 15))
    ax = fig.add_subplot(1, 1, 1, projection=crs.PlateCarree())
    ax.add_feature(cfeature.COASTLINE)
    ax.tick_params(axis='y', which='both', left=False, labelleft=False)
    
    land = cfeature.NaturalEarthFeature('physical', 'land', '10m', edgecolor='face', facecolor=cfeature.COLORS['land'])
    ocean = cfeature.NaturalEarthFeature('physical', 'ocean', '10m', edgecolor='face', facecolor=cfeature.COLORS['water'])
    
    ax.add_feature(land)
    ax.add_feature(ocean)
    
    ax.set_extent(extent, crs=crs.PlateCarree())
    
    gl = ax.gridlines(crs=crs.PlateCarree(), draw_labels=True)
    gl.top_labels = False  
    gl.right_labels = False 
     

    gl.xlines = False
    gl.ylines = False

    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER

    gl.xlabel_style = {'color': 'black'}  
    gl.ylabel_style = {'color': 'black'}  


    return fig, ax

