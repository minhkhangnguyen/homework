import numpy as np

def calculate_spatial_distance(df_ais, vessel_column_name):
    '''Calculate the spatial distance between adjacent points'''
    df_ais = df_ais.groupby(vessel_column_name, as_index=False).apply(_haversine)
    return df_ais

def _haversine(df, to_radians=True, earth_radius=6371):
    '''The haversine formula determines the great-circle distance between two points on a sphere, given their longitudes and latitudes'''
    lat1 = df['lat']
    lon1 = df['lon']
    lat2 = df['lat'].shift()
    lon2 = df['lon'].shift()

    if to_radians:
        lat1, lon1, lat2, lon2 = np.radians([lat1, lon1, lat2, lon2])

    a = np.sin((lat2 - lat1)/2.0)**2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1)/2.0)**2
    df['spatial_distance(km)'] = earth_radius * 2 * np.arcsin(np.sqrt(a))
    return df
